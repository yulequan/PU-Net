******************MeshSegmentation.exe******************

when running the exe file, please enter the following three parameters:

1, mesh file name
2, patch number you want to cut
3, patch radius for each patch

Following is an example:
MeshSegmentation.exe egea.off 10 5.0
